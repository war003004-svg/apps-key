package com.evotype.keyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ImageView
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(11, 16, 32)
    private val muted = Color.rgb(160, 171, 198)
    private val accent = Color.rgb(139, 124, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(30), dp(24), dp(24))
            setBackgroundColor(bg)
        }
        val brand = ImageView(this).apply {
            setImageResource(com.evotype.keyboard.R.drawable.evotype_wordmark)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_START
            contentDescription = "EvoType Keyboard"
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, dp(92)))
        val title = TextView(this).apply {
            text = "Your words.\nYour own style."
            textSize = 34f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, dp(34), 0, dp(12))
        }
        root.addView(title)
        val desc = TextView(this).apply {
            text = "A smarter multilingual keyboard experience. Type naturally, switch languages effortlessly, and make every word yours."
            textSize = 15f
            setTextColor(muted)
            setLineSpacing(dp(4).toFloat(), 1f)
        }
        root.addView(desc)

        val preview = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(20), dp(16), dp(20))
            background = rounded(Color.rgb(22, 30, 54), 24)
        }
        val previewTitle = TextView(this).apply {
            text = "EVOTYPE  •  ENGLISH"
            textSize = 11f
            letterSpacing = .1f
            setTextColor(accent)
            typeface = Typeface.DEFAULT_BOLD
        }
        preview.addView(previewTitle)
        val previewText = TextView(this).apply {
            text = "q  w  e  r  t  y  u  i  o  p\na  s  d  f  g  h  j  k  l\n⇧  z  x  c  v  b  n  m  ⌫"
            textSize = 17f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setLineSpacing(dp(14).toFloat(), 1f)
            setPadding(0, dp(18), 0, dp(6))
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        preview.addView(previewText)
        val params = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(34) }
        root.addView(preview, params)

        val steps = TextView(this).apply {
            text = "GET STARTED\n1. Enable EvoType Keyboard in Android keyboard settings.\n2. Select EvoType Keyboard as your current keyboard."
            textSize = 14f
            setTextColor(muted)
            setLineSpacing(dp(8).toFloat(), 1f)
            setPadding(0, dp(26), 0, dp(18))
        }
        root.addView(steps)
        val enable = Button(this).apply {
            text = "Enable EvoType Keyboard"
            isAllCaps = false
            textSize = 16f
            setTextColor(Color.WHITE)
            background = rounded(accent, 18)
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        }
        root.addView(enable, LinearLayout.LayoutParams(-1, dp(54)))
        val choose = Button(this).apply {
            text = "Choose keyboard"
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(39, 48, 76), 18)
            setOnClickListener {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }
        val chooseParams = LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(12) }
        root.addView(choose, chooseParams)
        setContentView(root)
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
