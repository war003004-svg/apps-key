package com.evotype.keyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputConnection
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class EvoInputMethodService : InputMethodService() {
    private var bangla = false
    private var banglishMode = false
    private var caps = false
    private var keyboardRoot: LinearLayout? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Int = 8) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    override fun onCreateInputView(): View {
        return buildKeyboard()
    }

    private fun buildKeyboard(): View {
        val theme = getSharedPreferences("evotype", MODE_PRIVATE).getInt("theme", 0)
        val base = when (theme) { 1 -> Color.rgb(28,31,45); 2 -> Color.rgb(224,250,244); else -> Color.rgb(231,237,252) }
        val keyColor = if (theme == 1) Color.rgb(55,60,78) else Color.WHITE
        val textColor = if (theme == 1) Color.WHITE else Color.rgb(25,34,70)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5), dp(7), dp(5), dp(7))
            background = bg(base, 16)
        }
        keyboardRoot = root

        val toolbar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        addKey(toolbar, if (banglishMode) "বাংলিশ" else if (bangla) "বাংলা" else "EN", 1f, keyColor, textColor) {
            banglishMode = !banglishMode
            if (banglishMode) bangla = false
            refresh()
        }
        addKey(toolbar, "😊", 1f, keyColor, textColor) { commit("😊") }
        addKey(toolbar, "✦", 1f, keyColor, textColor) { Toast.makeText(this, "Quick tools are coming soon", Toast.LENGTH_SHORT).show() }
        addKey(toolbar, "⌄", 1f, keyColor, textColor) { requestHideSelf(0) }
        root.addView(toolbar)

        if (bangla && !banglishMode) {
            listOf("অ আ ই ঈ উ ঊ এ ঐ ও ঔ", "ক খ গ ঘ ঙ চ ছ জ ঝ ঞ", "ট ঠ ড ঢ ণ ত থ দ ধ ন", "প ফ ব ভ ম য র ল শ ষ স হ").forEach { addRow(root, it.split(" "), keyColor, textColor) }
        } else {
            listOf("q w e r t y u i o p", "a s d f g h j k l", "⇧ z x c v b n m ⌫").forEach { row ->
                val keys = row.split(" ").toMutableList()
                val line = LinearLayout(this).apply { gravity = Gravity.CENTER }
                keys.forEach { key ->
                    val label = if (caps && key.length == 1) key.uppercase() else key
                    addKey(line, label, if (key == "⇧" || key == "⌫") 1.25f else 1f, if (key == "⇧" || key == "⌫") Color.rgb(199,211,250) else keyColor, textColor) {
                        when (key) {
                            "⇧" -> { caps = !caps; refresh() }
                            "⌫" -> currentInputConnection?.deleteSurroundingText(1, 0)
                            else -> {
                                if (banglishMode) {
                                    val ic = currentInputConnection
                                    val before = ic?.getTextBeforeCursor(80, 0)?.toString().orEmpty()
                                    val word = before.takeLastWhile { !it.isWhitespace() }
                                    if (key == " ") {
                                        val converted = Banglish.convert(word)
                                        if (converted != word && word.isNotEmpty()) {
                                            ic?.deleteSurroundingText(word.length, 0)
                                            ic?.commitText(converted, 1)
                                        }
                                        ic?.commitText(" ", 1)
                                    } else ic?.commitText(label, 1)
                                } else currentInputConnection?.commitText(label, 1)
                            }
                        }
                    }
                }
                root.addView(line)
            }
        }

        val bottom = LinearLayout(this).apply { gravity = Gravity.CENTER }
        addKey(bottom, "123", 1f, Color.rgb(199,211,250), textColor) { Toast.makeText(this, "Number row is planned", Toast.LENGTH_SHORT).show() }
        addKey(bottom, if (banglishMode) "বাংলা" else "🌐", 1f, Color.rgb(199,211,250), textColor) {
            if (banglishMode) { banglishMode = false; bangla = true } else bangla = !bangla
            refresh()
        }
        addKey(bottom, ",", .7f, keyColor, textColor) { commit(",") }
        addKey(bottom, "space", 3.4f, keyColor, textColor) { commitSpace() }
        addKey(bottom, ".", .7f, keyColor, textColor) { commit(".") }
        addKey(bottom, "↵", 1f, Color.rgb(49,91,255), Color.WHITE) { currentInputConnection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER)); currentInputConnection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_ENTER)) }
        root.addView(bottom)
        return root
    }

    private fun addRow(root: LinearLayout, keys: List<String>, keyColor: Int, textColor: Int) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        keys.forEach { k -> addKey(row, k, 1f, keyColor, textColor) { commit(k) } }
        root.addView(row)
    }

    private fun addKey(row: LinearLayout, label: String, weight: Float, color: Int, textColor: Int, action: () -> Unit) {
        val key = TextView(this).apply {
            text = label
            textSize = if (label.length > 4) 11f else 17f
            gravity = Gravity.CENTER
            setTextColor(textColor)
            typeface = Typeface.DEFAULT
            background = bg(color, 8)
            setOnClickListener { action() }
            setPadding(dp(2), dp(10), dp(2), dp(10))
        }
        val p = LinearLayout.LayoutParams(0, dp(43), weight)
        p.setMargins(dp(2), dp(3), dp(2), dp(3))
        row.addView(key, p)
    }

    private fun commit(s: String) { currentInputConnection?.commitText(s, 1) }

    private fun commitSpace() {
        val ic = currentInputConnection
        if (banglishMode && ic != null) {
            val before = ic.getTextBeforeCursor(80, 0)?.toString().orEmpty()
            val word = before.takeLastWhile { !it.isWhitespace() }
            if (word.isNotEmpty()) {
                val converted = Banglish.convert(word)
                if (converted != word) {
                    ic.deleteSurroundingText(word.length, 0)
                    ic.commitText(converted, 1)
                }
            }
        }
        ic?.commitText(" ", 1)
    }

    private fun refresh() {
        inputView = buildKeyboard()
    }
}
