package com.evotype.keyboard

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val navy = Color.rgb(16, 27, 85)
    private val blue = Color.rgb(35, 91, 255)
    private val purple = Color.rgb(104, 35, 235)
    private val ink = Color.rgb(25, 34, 70)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showPage("Home")
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 18): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun text(value: String, size: Float, color: Int = ink, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun button(label: String, onClick: () -> Unit, filled: Boolean = false): TextView =
        TextView(this).apply {
            text = label
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(if (filled) Color.WHITE else ink)
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(if (filled) blue else Color.WHITE, 14)
            setOnClickListener { onClick() }
        }

    private fun showPage(page: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(248, 249, 255))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(18))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(navy, blue, purple)
            ).apply { cornerRadii = floatArrayOf(0f,0f,0f,0f,dp(24).toFloat(),dp(24).toFloat(),dp(24).toFloat(),dp(24).toFloat()) }
        }
        header.addView(text("EvoType", 28f, Color.WHITE, true))
        header.addView(text("KEYBOARD  •  ${page.uppercase()}", 11f, Color.rgb(220,228,255), true))
        root.addView(header)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        listOf("Home", "Themes", "Languages", "Settings").forEach { item ->
            val b = TextView(this).apply {
                text = item
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(if (page == item) blue else ink)
                setPadding(dp(8), dp(12), dp(8), dp(12))
                setOnClickListener { showPage(item) }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)

        when (page) {
            "Home" -> home()
            "Test" -> {
                section("Keyboard test", "Tap the field below, then choose EvoType from the keyboard switcher.")
                val edit = EditText(this).apply {
                    hint = "এখানে টাইপ করুন / Start typing…"
                    textSize = 18f
                    minLines = 4
                    setPadding(dp(14), dp(14), dp(14), dp(14))
                    background = rounded(Color.WHITE, 16)
                }
                content.addView(edit, LinearLayout.LayoutParams(-1, dp(150)))
                content.addView(space(14))
                content.addView(button("BACK TO HOME", { showPage("Home") }, true))
            }
            "Themes" -> themes()
            "Languages" -> languages()
            "Settings" -> settings()
            "Shortcuts" -> simplePage("Quick shortcuts", "Frequently used actions will live here.", listOf("Text replacement", "Quick symbols", "One-handed mode"))
            "Clipboard" -> simplePage("Clipboard", "A private on-device clipboard history is planned for a later build.", listOf("Clipboard history", "Pinned snippets"))
            "Privacy" -> simplePage("Privacy center", "The first MVP does not send typed text to a server. Do not type passwords into test builds.", listOf("On-device processing", "Permissions", "Data policy"))
            "About" -> simplePage("About EvoType", "A keyboard project built around comfortable Bangla and English typing.", listOf("Version 0.1.0", "Made for Android first", "iOS edition planned separately"))
        }
    }

    private fun section(title: String, subtitle: String? = null) {
        content.addView(text(title, 19f, ink, true))
        if (subtitle != null) {
            val s = text(subtitle, 13f, Color.rgb(105, 115, 145))
            s.setPadding(0, dp(5), 0, dp(10))
            content.addView(s)
        } else content.addView(space(10))
    }

    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }

    private fun card(title: String, desc: String, action: String? = null, onClick: (() -> Unit)? = null) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(Color.WHITE, 18)
            elevation = dp(1).toFloat()
        }
        box.addView(text(title, 16f, ink, true))
        val d = text(desc, 13f, Color.rgb(105,115,145))
        d.setPadding(0, dp(6), 0, dp(8))
        box.addView(d)
        if (action != null && onClick != null) {
            box.addView(button(action, onClick, true))
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(12)
        content.addView(box, lp)
    }

    private fun home() {
        section("Your keyboard, evolved.", "A cleaner way to type in Bangla and English.")
        card("⌨  Activate EvoType", "Enable EvoType in Android keyboard settings, then select it from the keyboard switcher.", "OPEN KEYBOARD SETTINGS") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        card("✦  Try your keyboard", "Open a test field and switch to EvoType to check the live keyboard.", "OPEN TEST FIELD") {
            showPage("Test")
        }
        section("Explore EvoType")
        card("Color themes", "Choose a visual style for your keyboard.", "VIEW THEMES") { showPage("Themes") }
        card("Languages & typing", "Bangla + English in this first release. More transliteration modes later.", "LANGUAGE SETTINGS") { showPage("Languages") }
        card("Quick tools", "Shortcuts, clipboard and privacy options.", "EXPLORE TOOLS") { showPage("Shortcuts") }
        card("Voice, GIF & stickers", "Planned integrations. Voice typing can depend on the speech service available on the device.", null, null)
    }

    private fun themes() {
        section("Make it yours", "Select a theme. The keyboard reads this choice on its next opening.")
        listOf("Ocean Blue" to 0, "Midnight" to 1, "Mint Glow" to 2).forEach { (name, id) ->
            card(name, when(id) { 0 -> "Blue and violet gradient • EvoType signature"; 1 -> "Dark keys for a low-light look"; else -> "Fresh teal accent with light keys" }, "APPLY THEME") {
                getSharedPreferences("evotype", MODE_PRIVATE).edit().putInt("theme", id).apply()
                Toast.makeText(this, "$name applied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun languages() {
        section("Typing languages", "The first release focuses on a reliable Bangla + English foundation.")
        card("বাংলা", "Bangla keyboard layout • planned phonetic suggestions", null, null)
        card("English", "QWERTY layout • basic punctuation and emoji row", null, null)
        card("Banglish → বাংলা", "Initial word conversion support is included in the keyboard service. It will improve as the dictionary grows.", null, null)
        card("Coming later", "Hindi / Hinglish, Roman Urdu, Arabizi, Romaji, Pinyin, Punjabi and more.", null, null)
    }

    private fun settings() {
        section("Keyboard settings", "The options below are the first settings hub.")
        card("Keyboard setup", "Enable EvoType and choose it as your current input method.", "SET UP") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        card("Shortcuts", "Quick symbols and text tools.", "OPEN") { showPage("Shortcuts") }
        card("Clipboard", "Local clipboard tools are planned.", "OPEN") { showPage("Clipboard") }
        card("Privacy", "Understand how keyboard data should be handled.", "OPEN") { showPage("Privacy") }
        card("About", "Version, project information and roadmap.", "OPEN") { showPage("About") }
    }

    private fun simplePage(title: String, desc: String, items: List<String>) {
        section(title, desc)
        items.forEach { card(it, "This area is part of the EvoType interface foundation.", null, null) }
        content.addView(button("BACK TO HOME", { showPage("Home") }, true))
    }
}
