package com.evotype.keyboard

object Banglish {
    private val words = mapOf(
        "ami" to "আমি", "tumi" to "তুমি", "apni" to "আপনি", "amra" to "আমরা",
        "bhalo" to "ভালো", "valo" to "ভালো", "baschi" to "বাসছি", "bhalobashi" to "ভালোবাসি",
        "tomake" to "তোমাকে", "kemon" to "কেমন", "acho" to "আছো", "achhi" to "আছি",
        "ki" to "কি", "keno" to "কেন", "kothay" to "কোথায়", "dhonnobad" to "ধন্যবাদ",
        "bangla" to "বাংলা", "বাংলা" to "বাংলা", "na" to "না", "hya" to "হ্যাঁ",
        "amar" to "আমার", "name" to "নাম", "onek" to "অনেক", "sundor" to "সুন্দর",
        "chai" to "চাই", "korbo" to "করব", "hobe" to "হবে", "theke" to "থেকে"
    )

    fun convert(input: String): String {
        val key = input.lowercase()
        words[key]?.let { return it }
        // Small fallback transliterator. This is intentionally conservative; a full phonetic
        // engine and a much larger lexicon are required for production-quality Banglish.
        val digraphs = listOf("kh" to "খ", "gh" to "ঘ", "chh" to "ছ", "ch" to "চ",
            "jh" to "ঝ", "th" to "থ", "dh" to "ধ", "ph" to "ফ", "bh" to "ভ",
            "sh" to "শ", "ng" to "ং", "ny" to "ঞ")
        var s = key
        digraphs.forEach { (a,b) -> s = s.replace(a,b) }
        val map = mapOf(
            'a' to "া", 'i' to "ি", 'e' to "ে", 'o' to "ো", 'u' to "ু",
            'k' to "ক", 'g' to "গ", 'c' to "ক", 'j' to "জ", 't' to "ত",
            'd' to "দ", 'n' to "ন", 'p' to "প", 'f' to "ফ", 'b' to "ব",
            'm' to "ম", 'y' to "য়", 'r' to "র", 'l' to "ল", 's' to "স",
            'h' to "হ", 'w' to "ও", 'v' to "ভ", 'z' to "জ", 'q' to "ক"
        )
        return buildString {
            s.forEach { ch -> append(map[ch] ?: ch.toString()) }
        }
    }
}
