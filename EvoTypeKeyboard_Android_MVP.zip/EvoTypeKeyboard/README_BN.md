# EvoType Keyboard — Android MVP (v0.1.0)

এটি EvoType-এর প্রথম Android-native starter project। VS Code-এ source edit করা যাবে। এটি এখনো Play Store release-ready পূর্ণাঙ্গ কিবোর্ড নয়।

## প্রথম সংস্করণে যা আছে
- Native Android `InputMethodService` keyboard foundation
- English QWERTY keyboard
- প্রাথমিক বাংলা অক্ষর লেআউট
- Basic Banglish → বাংলা word conversion prototype
- তিনটি local keyboard theme
- Home, Themes, Languages, Settings, Shortcuts, Clipboard, Privacy, About পেজের UI foundation
- Android Input Method Settings খোলার setup action
- কোনো account বা remote server বাধ্যতামূলক নয়

## এখনো অসম্পূর্ণ / পরবর্তী কাজ
- Production-quality phonetic Banglish engine, suggestion strip, autocorrect
- Hindi/Hinglish ও অন্যান্য romanized language
- পূর্ণ emoji picker, GIF/sticker provider integration
- Keyboard-এর ভেতরে নির্ভরযোগ্য voice-to-text integration
- Real clipboard history, text shortcuts, number/symbol pages
- Accessibility, OEM compatibility, performance and privacy audit
- iOS edition (iOS keyboard extension আলাদা করে তৈরি করতে হবে)

## Build prerequisites
- Windows 11
- JDK 17
- Android SDK Command-line Tools
- Android SDK Platform 35 এবং Build Tools 35.x
- Gradle 8.9
- VS Code (Kotlin/Java extension সহ)

> Android Studio বাধ্যতামূলক নয়। তবে Android SDK ও Gradle লাগবে। প্রথম build-এ Google Maven/Maven Central থেকে Android Gradle Plugin/Kotlin plugin download হতে পারে।

## Build (Windows)
1. Android SDK install করে `ANDROID_HOME` environment variable সেট করুন।
2. JDK 17 install করে `JAVA_HOME` সেট করুন।
3. Gradle 8.9 install করে PATH-এ যোগ করুন।
4. VS Code-এ এই project folder খুলুন।
5. Terminal-এ চালান:

```bat
gradle --version
gradle assembleDebug
```

APK তৈরি হলে:
`app\build\outputs\apk\debug\app-debug.apk`

## ফোনে keyboard চালু
1. APK install করুন।
2. EvoType Keyboard app খুলুন।
3. `ACTIVATE EVOTYPE` চাপুন।
4. Android settings থেকে EvoType Keyboard enable করুন।
5. কোনো text field-এ গিয়ে keyboard switcher থেকে EvoType বেছে নিন।

কিছু Android নির্মাতার Settings screen-এর নাম আলাদা হতে পারে।

## গুরুত্বপূর্ণ
- `minSdk = 23` রাখা হয়েছে, অর্থাৎ Android 6.0+ লক্ষ্য করে; বাস্তব ডিভাইসে পরীক্ষা ছাড়া সব ফোনে নিশ্চয়তা দেওয়া যায় না।
- Banglish converter এখন prototype। বাংলা-ইংরেজি মিশ্র লেখা, যুক্তাক্ষর, context, spelling variation ইত্যাদিতে ভুল হতে পারে।
- এই build-এ voice, GIF এবং sticker সম্পূর্ণ বাস্তবায়িত নয়। সেগুলোকে UI roadmap হিসেবে দেখানো হয়েছে।
- Keyboard app sensitive input handle করতে পারে। ভবিষ্যৎ সংস্করণে typed text log বা server-এ পাঠানো যাবে না; privacy review বাধ্যতামূলক।
